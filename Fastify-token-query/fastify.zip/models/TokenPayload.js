"use strict";
exports.__esModule = true;
var TokenPayload = /** @class */ (function () {
    function TokenPayload(username, firstName, lastName) {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    return TokenPayload;
}());
exports.TokenPayload = TokenPayload;
