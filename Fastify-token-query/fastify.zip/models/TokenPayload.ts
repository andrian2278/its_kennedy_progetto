export class TokenPayload{
    constructor(public username: string,
                public firstName: string,
                public lastName: string){

    }
}