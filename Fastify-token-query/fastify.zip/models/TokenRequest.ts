  
export interface TokenRequest {
    username: string;
    password: string;
}